﻿
namespace Exercise3
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.inputButton = new System.Windows.Forms.Label();
            this.outputButton = new System.Windows.Forms.Label();
            this.inputTextBox = new System.Windows.Forms.TextBox();
            this.outputTextBox = new System.Windows.Forms.TextBox();
            this.convertButton = new System.Windows.Forms.Button();
            this.marsToEarthConvertButton = new System.Windows.Forms.Button();
            this.clearFieldsButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // inputButton
            // 
            this.inputButton.AutoSize = true;
            this.inputButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.inputButton.Location = new System.Drawing.Point(82, 78);
            this.inputButton.Name = "inputButton";
            this.inputButton.Size = new System.Drawing.Size(223, 20);
            this.inputButton.TabIndex = 0;
            this.inputButton.Text = "Enter your weight on Earth";
            this.inputButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // outputButton
            // 
            this.outputButton.AutoSize = true;
            this.outputButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.outputButton.Location = new System.Drawing.Point(132, 132);
            this.outputButton.Name = "outputButton";
            this.outputButton.Size = new System.Drawing.Size(173, 20);
            this.outputButton.TabIndex = 1;
            this.outputButton.Text = "Your weight on Mars";
            this.outputButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // inputTextBox
            // 
            this.inputTextBox.Location = new System.Drawing.Point(311, 75);
            this.inputTextBox.Name = "inputTextBox";
            this.inputTextBox.Size = new System.Drawing.Size(100, 23);
            this.inputTextBox.TabIndex = 2;
            // 
            // outputTextBox
            // 
            this.outputTextBox.Location = new System.Drawing.Point(311, 132);
            this.outputTextBox.Name = "outputTextBox";
            this.outputTextBox.Size = new System.Drawing.Size(100, 23);
            this.outputTextBox.TabIndex = 3;
            // 
            // convertButton
            // 
            this.convertButton.BackColor = System.Drawing.SystemColors.ControlLight;
            this.convertButton.FlatAppearance.BorderColor = System.Drawing.SystemColors.Highlight;
            this.convertButton.FlatAppearance.BorderSize = 2;
            this.convertButton.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.convertButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.convertButton.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.convertButton.Location = new System.Drawing.Point(132, 194);
            this.convertButton.Name = "convertButton";
            this.convertButton.Size = new System.Drawing.Size(115, 46);
            this.convertButton.TabIndex = 4;
            this.convertButton.Text = "Convert Earth to Mars";
            this.convertButton.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.convertButton.UseVisualStyleBackColor = false;
            this.convertButton.Click += new System.EventHandler(this.convertButton_Click);
            // 
            // marsToEarthConvertButton
            // 
            this.marsToEarthConvertButton.BackColor = System.Drawing.SystemColors.ControlLight;
            this.marsToEarthConvertButton.FlatAppearance.BorderColor = System.Drawing.SystemColors.Highlight;
            this.marsToEarthConvertButton.FlatAppearance.BorderSize = 2;
            this.marsToEarthConvertButton.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.marsToEarthConvertButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.marsToEarthConvertButton.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.marsToEarthConvertButton.Location = new System.Drawing.Point(296, 194);
            this.marsToEarthConvertButton.Name = "marsToEarthConvertButton";
            this.marsToEarthConvertButton.Size = new System.Drawing.Size(115, 46);
            this.marsToEarthConvertButton.TabIndex = 5;
            this.marsToEarthConvertButton.Text = "Convert Mars to Earth";
            this.marsToEarthConvertButton.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.marsToEarthConvertButton.UseVisualStyleBackColor = false;
            this.marsToEarthConvertButton.Click += new System.EventHandler(this.marsToEarthConvertButton_Click);
            // 
            // clearFieldsButton
            // 
            this.clearFieldsButton.BackColor = System.Drawing.SystemColors.ControlLight;
            this.clearFieldsButton.FlatAppearance.BorderColor = System.Drawing.SystemColors.Highlight;
            this.clearFieldsButton.FlatAppearance.BorderSize = 2;
            this.clearFieldsButton.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.clearFieldsButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.clearFieldsButton.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.clearFieldsButton.Location = new System.Drawing.Point(225, 267);
            this.clearFieldsButton.Name = "clearFieldsButton";
            this.clearFieldsButton.Size = new System.Drawing.Size(95, 46);
            this.clearFieldsButton.TabIndex = 6;
            this.clearFieldsButton.Text = "Clear Text Fields";
            this.clearFieldsButton.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.clearFieldsButton.UseVisualStyleBackColor = false;
            this.clearFieldsButton.Click += new System.EventHandler(this.clearFieldsButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Chocolate;
            this.ClientSize = new System.Drawing.Size(603, 371);
            this.Controls.Add(this.clearFieldsButton);
            this.Controls.Add(this.marsToEarthConvertButton);
            this.Controls.Add(this.convertButton);
            this.Controls.Add(this.outputTextBox);
            this.Controls.Add(this.inputTextBox);
            this.Controls.Add(this.outputButton);
            this.Controls.Add(this.inputButton);
            this.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.Name = "Form1";
            this.Text = "Your Weight on Mars";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label inputButton;
        private System.Windows.Forms.Label outputButton;
        private System.Windows.Forms.TextBox inputTextBox;
        private System.Windows.Forms.TextBox outputTextBox;
        private System.Windows.Forms.Button convertButton;
        private System.Windows.Forms.Button marsToEarthConvertButton;
        private System.Windows.Forms.Button clearFieldsButton;
    }
}

