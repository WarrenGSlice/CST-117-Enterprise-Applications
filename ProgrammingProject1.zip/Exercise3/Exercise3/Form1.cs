﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Exercise3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void convertButton_Click(object sender, EventArgs e)
        {
            //Variables
            double lbs; // To hold lbs entered
            double weight; // To hold conversion variable for weight on Earth

            // Loop that rounds the numbers and outputs results of Earth to Mars Conversion
            if (double.TryParse(inputTextBox.Text, out _))
            {
                // Get the lbs entered and assign it to the lbs variable
                lbs = double.Parse(inputTextBox.Text);

                // Calculate Earth weight to Mars weight
                weight = (double)((lbs / 9.81) * 3.711);

                // Display the conversion from earth to mars in outputLabel
                outputTextBox.Text = weight.ToString("n3");
            }
            else
            {
                //Invalid Entry
                MessageBox.Show("Invalid Entry, Please enter a valid number");
            }
        }

        private void marsToEarthConvertButton_Click(object sender, EventArgs e)
        {
            // Variables
            double marsLbs; // To hold lbs entered on Mars
            double marsWeight; // To hold conversion variable for weight on Mars

            // Loops that rounds the numbers and outputs results of mars to Earth Conversion
            if (double.TryParse(outputTextBox.Text, out _))
            {
                // Get the lbs entered and assign it to the lbs variable
                marsLbs = double.Parse(outputTextBox.Text);

                // Calculate Mars weight to Earth weight
                marsWeight = (double)((marsLbs / 3.711) * 9.81);

                //Display the convserion from mars to earth in inputLabel
                inputTextBox.Text = marsWeight.ToString("n3");
            }
            else
            {
                //Invalid Entry
                MessageBox.Show("Invalid Entry, Please enter a valid number");
            }
        }

        private void clearFieldsButton_Click(object sender, EventArgs e)
        {
            // Reset fields
            inputTextBox.Text = "";
            outputTextBox.Text = "";
        }
    }
}
