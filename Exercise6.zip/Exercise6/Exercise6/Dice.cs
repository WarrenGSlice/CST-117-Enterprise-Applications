﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/* * * * * * * * * * * * * * * *
 * * * * Warren Peterson * * * *
 * * * This is my own work * * *
 * * * CST-117   4/23/2021 * * *
 * * * *  Exercise 6 * * * * * *
 * * * * * * * * * * * * * * * */
namespace Exercise6
{ // Dice Class
    class Dice
    {
        private int sides; //variable used to create sides

        //Dice constructor
        public Dice(int sides)
        {
            this.sides = sides;
        }
        // Uses random number to roll the dice and returns the face value
        public int rollDie()
        {
            return Randomizer.generate(sides);
        }
    }
}
