﻿
namespace Exercise6
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.DicePictureBox1 = new System.Windows.Forms.PictureBox();
            this.RollDiceButton = new System.Windows.Forms.Button();
            this.DicePictureBox2 = new System.Windows.Forms.PictureBox();
            this.ResultsLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.DicePictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DicePictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // DicePictureBox1
            // 
            this.DicePictureBox1.BackColor = System.Drawing.Color.Aquamarine;
            this.DicePictureBox1.Image = global::Exercise6.Properties.Resources.dice6;
            this.DicePictureBox1.Location = new System.Drawing.Point(51, 76);
            this.DicePictureBox1.Name = "DicePictureBox1";
            this.DicePictureBox1.Size = new System.Drawing.Size(135, 123);
            this.DicePictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.DicePictureBox1.TabIndex = 0;
            this.DicePictureBox1.TabStop = false;
            // 
            // RollDiceButton
            // 
            this.RollDiceButton.BackColor = System.Drawing.Color.Violet;
            this.RollDiceButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.RollDiceButton.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.RollDiceButton.Location = new System.Drawing.Point(106, 199);
            this.RollDiceButton.Name = "RollDiceButton";
            this.RollDiceButton.Size = new System.Drawing.Size(173, 51);
            this.RollDiceButton.TabIndex = 1;
            this.RollDiceButton.Text = "Roll The Dice";
            this.RollDiceButton.UseVisualStyleBackColor = false;
            this.RollDiceButton.Click += new System.EventHandler(this.RollDiceButton_Click);
            // 
            // DicePictureBox2
            // 
            this.DicePictureBox2.BackColor = System.Drawing.Color.Aquamarine;
            this.DicePictureBox2.Image = global::Exercise6.Properties.Resources.dice6;
            this.DicePictureBox2.Location = new System.Drawing.Point(192, 76);
            this.DicePictureBox2.Name = "DicePictureBox2";
            this.DicePictureBox2.Size = new System.Drawing.Size(135, 123);
            this.DicePictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.DicePictureBox2.TabIndex = 2;
            this.DicePictureBox2.TabStop = false;
            // 
            // ResultsLabel
            // 
            this.ResultsLabel.AutoSize = true;
            this.ResultsLabel.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.ResultsLabel.Location = new System.Drawing.Point(51, 25);
            this.ResultsLabel.Name = "ResultsLabel";
            this.ResultsLabel.Size = new System.Drawing.Size(90, 25);
            this.ResultsLabel.TabIndex = 3;
            this.ResultsLabel.Text = "Rolling...";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Exercise6.Properties.Resources.dice;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(380, 329);
            this.Controls.Add(this.ResultsLabel);
            this.Controls.Add(this.DicePictureBox2);
            this.Controls.Add(this.RollDiceButton);
            this.Controls.Add(this.DicePictureBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Dice App";
            ((System.ComponentModel.ISupportInitialize)(this.DicePictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DicePictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox DicePictureBox1;
        private System.Windows.Forms.Button RollDiceButton;
        private System.Windows.Forms.PictureBox DicePictureBox2;
        private System.Windows.Forms.Label ResultsLabel;
    }
}

