﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/* * * * * * * * * * * * * * * *
 * * * * Warren Peterson * * * *
 * * * This is my own work * * *
 * * * CST-117   4/23/2021 * * *
 * * * *  Exercise 6 * * * * * *
 * * * * * * * * * * * * * * * */
namespace Exercise6
{
    // Random Class that generates the randomizer
    class Randomizer
    {
        public static Random dice = new Random();
        public static int generate(int max)
        {
            return dice.Next(1, max + 1);
        }
    }
}
