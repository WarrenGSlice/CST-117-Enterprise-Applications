﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/* * * * * * * * * * * * * * * *
 * * * * Warren Peterson * * * *
 * * * This is my own work * * *
 * * * CST-117   4/23/2021 * * *
 * * * *  Exercise 6 * * * * * *
 * * * * * * * * * * * * * * * */       
namespace Exercise6
{
    public partial class Form1 : Form
    {
        // Variables
        private int fontSize = 50; //Variable to set font size
        private int rollCount = 0; // Variable that declares rollCount to type Int and sets it to a value of 0
        private Dice diceOne; // Variable that declares diceOne to the object type Dice from the Dice class
        private Dice diceTwo; // Variable that declares diceTwo to the object type Dice from the Dice class
        private int diceOneResults = 0; // Variable that declares diceOneResults to the type integer and sets the default value to 0
        private int diceTwoResults = 0; // Variable that declares diceTwoResults to the type integer and sets the default value to 0

        public Form1()
        {
            InitializeComponent();
            // Creates the dice objects and the argument passed is the number of sides
            diceOne = new Dice(6);
            diceTwo = new Dice(6);
        }

        // Roll Dice Button
        private void RollDiceButton_Click(object sender, EventArgs e)
        {
            startRoll();            // Start roll method invoked
            // Loop that says if the dice are not snake eyes, roll the dice and show the results for half a second
            while (!IsSnakeEyes())
            {
                rollDice();
                System.Threading.Thread.Sleep(500);
            }
            RollDiceButton.Enabled = true; // enable the roll dice button
            ResultsLabel.Text = "It took " + rollCount.ToString() + " rolls to get snake eyes"; // shows how many rolls it took to get snake eyes
        }
        // Start the Roll Method
        private void startRoll()
        {
            RollDiceButton.Enabled = false; // once the dice are rolling, disable the rolldice button
            diceOneResults = 0; // starting value of dicce
            diceTwoResults = 0; //starting valye of dice
            ResultsLabel.Text = "Rolling..."; // default message 
            rollCount = 0; // starting roll count
        }
        // End of game Method
        private bool IsSnakeEyes()
        {
            return diceOneResults == 1 && diceTwoResults == 1; // if the result is snake eyes, return the snake eyes method
        }
        // Rolling Dice method
        private void rollDice()
        {
            rollCount++; //increments roll count for each roll
            diceOneResults = diceOne.rollDie(); //generates the results of the rolled dice
            diceTwoResults = diceTwo.rollDie(); // generates the results of the rolled dice
            DiceGraphics(); //method that generates the graphics of the dice
        }

        // Dice Graphics Method
        private void DiceGraphics()
        {
            SolidBrush sbBlack = new SolidBrush(Color.Black);
            Graphics diceOnePanelGraphics = DicePictureBox1.CreateGraphics(); // The Picture Box uses the .net create graphics method
            Font diceOneFont = new Font("Arial", fontSize);
            diceOnePanelGraphics.FillRectangle(sbBlack, 0, 0, DicePictureBox1.Width, DicePictureBox1.Height); // sets the size of the graphics to the size of the picture box
            diceOnePanelGraphics.DrawString(diceOneResults.ToString(), diceOneFont, Brushes.White, new PointF((DicePictureBox1.Width / 2) - (fontSize / 1.5F), (DicePictureBox1.Height / 2) - (fontSize / 1.5F))); // Sets the dice results to createGraphics method to show the correct dice each roll

            SolidBrush sbGreen = new SolidBrush(Color.Green);
            Graphics diceTwoPanelGraphics = DicePictureBox2.CreateGraphics();
            Font diceTwoFont = new Font("Times New Roman", fontSize);
            diceTwoPanelGraphics.FillRectangle(sbGreen, 0, 0, DicePictureBox2.Width, DicePictureBox2.Height);
            diceTwoPanelGraphics.DrawString(diceTwoResults.ToString(), diceTwoFont, Brushes.White, new PointF((DicePictureBox2.Width / 2) - (fontSize / 1.5F), (DicePictureBox2.Height / 2) - (fontSize / 1.5F)));
        }
        // Image Dice Method
        // Was create to try and show an actual dice returned while the dice are rolling
        // It did not work correctly because it was not able to return the correct results to the corresponding image
        private void ImageDice()
        {
            ImageList ImageList = new ImageList();

            ImageList.ImageSize = new Size(135, 123);
            ImageList.Images.Add(Image.FromFile("C:\\Users\\warre\\OneDrive\\Documents\\CST-117\\Exercise6\\Exercise6\\Resources\\dice1.png"));
            ImageList.Images.Add(Image.FromFile("C:\\Users\\warre\\OneDrive\\Documents\\CST-117\\Exercise6\\Exercise6\\Resources\\dice2.png"));
            ImageList.Images.Add(Image.FromFile("C:\\Users\\warre\\OneDrive\\Documents\\CST-117\\Exercise6\\Exercise6\\Resources\\dice3.png"));
            ImageList.Images.Add(Image.FromFile("C:\\Users\\warre\\OneDrive\\Documents\\CST-117\\Exercise6\\Exercise6\\Resources\\dice4.png"));
            ImageList.Images.Add(Image.FromFile("C:\\Users\\warre\\OneDrive\\Documents\\CST-117\\Exercise6\\Exercise6\\Resources\\dice5.png"));
            ImageList.Images.Add(Image.FromFile("C:\\Users\\warre\\OneDrive\\Documents\\CST-117\\Exercise6\\Exercise6\\Resources\\dice6.png"));

            Graphics diceOnePanelGraphics = DicePictureBox1.CreateGraphics();
            diceOnePanelGraphics.DrawString(diceOneResults.ToString(), DefaultFont, Brushes.White, new PointF((DicePictureBox2.Width / 2) - (fontSize / 1.5F), (DicePictureBox2.Height / 2) - (fontSize / 1.5F)));
            Graphics diceTwoPanelGraphics = DicePictureBox2.CreateGraphics();

            // This loop makes a looping of the imageList, however it did not correctly show the correct number of the dice because there was no where to pass the diceResults object correctly.
            for(int count = 0; count<ImageList.Images.Count; count++)
            {
                if (diceOneResults.ToString() == diceOnePanelGraphics.ToString()) 
                {
                    ImageList.Draw(diceOnePanelGraphics, new Point(0, 0), count);
                    Application.DoEvents();
                    System.Threading.Thread.Sleep(100);
                }
            }
            for (int count = 0; count < ImageList.Images.Count; count++)
            {
                ImageList.Draw(diceTwoPanelGraphics, new Point(0, 0), count);
                Application.DoEvents();
                System.Threading.Thread.Sleep(100);
            }

        }
    }
}