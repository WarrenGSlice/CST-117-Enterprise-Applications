﻿
namespace ProgrammingProject3
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.ChooseFileLabel = new System.Windows.Forms.Label();
            this.ChooseFileButton = new System.Windows.Forms.Button();
            this.FileFactsLabel = new System.Windows.Forms.Label();
            this.FileFactsTextBox = new System.Windows.Forms.TextBox();
            this.FileFactsGroupBox = new System.Windows.Forms.GroupBox();
            this.FirstWordLabel = new System.Windows.Forms.Label();
            this.LastWordLabel = new System.Windows.Forms.Label();
            this.LongestWordLabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.openFile = new System.Windows.Forms.OpenFileDialog();
            this.saveFile = new System.Windows.Forms.SaveFileDialog();
            this.button1 = new System.Windows.Forms.Button();
            this.FileFactsGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // ChooseFileLabel
            // 
            this.ChooseFileLabel.AutoSize = true;
            this.ChooseFileLabel.BackColor = System.Drawing.Color.Transparent;
            this.ChooseFileLabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.ChooseFileLabel.Location = new System.Drawing.Point(62, 82);
            this.ChooseFileLabel.Name = "ChooseFileLabel";
            this.ChooseFileLabel.Size = new System.Drawing.Size(118, 21);
            this.ChooseFileLabel.TabIndex = 0;
            this.ChooseFileLabel.Text = "Choose a File :";
            // 
            // ChooseFileButton
            // 
            this.ChooseFileButton.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ChooseFileButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.ChooseFileButton.Font = new System.Drawing.Font("Segoe UI Black", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.ChooseFileButton.ForeColor = System.Drawing.Color.Black;
            this.ChooseFileButton.Location = new System.Drawing.Point(195, 71);
            this.ChooseFileButton.Name = "ChooseFileButton";
            this.ChooseFileButton.Size = new System.Drawing.Size(103, 43);
            this.ChooseFileButton.TabIndex = 1;
            this.ChooseFileButton.Text = "CREATE ";
            this.ChooseFileButton.UseVisualStyleBackColor = false;
            this.ChooseFileButton.Click += new System.EventHandler(this.ChooseFileButton_Click);
            // 
            // FileFactsLabel
            // 
            this.FileFactsLabel.AutoSize = true;
            this.FileFactsLabel.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.FileFactsLabel.ForeColor = System.Drawing.Color.White;
            this.FileFactsLabel.Location = new System.Drawing.Point(6, 0);
            this.FileFactsLabel.Name = "FileFactsLabel";
            this.FileFactsLabel.Size = new System.Drawing.Size(203, 15);
            this.FileFactsLabel.TabIndex = 2;
            this.FileFactsLabel.Text = "File Facts Converted to LowerCase :";
            // 
            // FileFactsTextBox
            // 
            this.FileFactsTextBox.BackColor = System.Drawing.Color.Beige;
            this.FileFactsTextBox.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.FileFactsTextBox.Location = new System.Drawing.Point(6, 18);
            this.FileFactsTextBox.MaximumSize = new System.Drawing.Size(275, 146);
            this.FileFactsTextBox.MinimumSize = new System.Drawing.Size(275, 146);
            this.FileFactsTextBox.Multiline = true;
            this.FileFactsTextBox.Name = "FileFactsTextBox";
            this.FileFactsTextBox.Size = new System.Drawing.Size(275, 146);
            this.FileFactsTextBox.TabIndex = 3;
            // 
            // FileFactsGroupBox
            // 
            this.FileFactsGroupBox.BackColor = System.Drawing.Color.DarkSlateGray;
            this.FileFactsGroupBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.FileFactsGroupBox.Controls.Add(this.FileFactsLabel);
            this.FileFactsGroupBox.Controls.Add(this.FileFactsTextBox);
            this.FileFactsGroupBox.Location = new System.Drawing.Point(324, 208);
            this.FileFactsGroupBox.Name = "FileFactsGroupBox";
            this.FileFactsGroupBox.Size = new System.Drawing.Size(286, 172);
            this.FileFactsGroupBox.TabIndex = 4;
            this.FileFactsGroupBox.TabStop = false;
            this.FileFactsGroupBox.Text = "File Facts Converted to LowerCase :";
            // 
            // FirstWordLabel
            // 
            this.FirstWordLabel.AutoSize = true;
            this.FirstWordLabel.BackColor = System.Drawing.Color.Transparent;
            this.FirstWordLabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.FirstWordLabel.Location = new System.Drawing.Point(172, 226);
            this.FirstWordLabel.Name = "FirstWordLabel";
            this.FirstWordLabel.Size = new System.Drawing.Size(146, 21);
            this.FirstWordLabel.TabIndex = 5;
            this.FirstWordLabel.Text = "First Word in File :";
            // 
            // LastWordLabel
            // 
            this.LastWordLabel.AutoSize = true;
            this.LastWordLabel.BackColor = System.Drawing.Color.Transparent;
            this.LastWordLabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.LastWordLabel.ForeColor = System.Drawing.Color.Black;
            this.LastWordLabel.Location = new System.Drawing.Point(174, 247);
            this.LastWordLabel.Name = "LastWordLabel";
            this.LastWordLabel.Size = new System.Drawing.Size(144, 21);
            this.LastWordLabel.TabIndex = 6;
            this.LastWordLabel.Text = "Last Word in File :";
            // 
            // LongestWordLabel
            // 
            this.LongestWordLabel.AutoSize = true;
            this.LongestWordLabel.BackColor = System.Drawing.Color.Transparent;
            this.LongestWordLabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.LongestWordLabel.Location = new System.Drawing.Point(144, 268);
            this.LongestWordLabel.Name = "LongestWordLabel";
            this.LongestWordLabel.Size = new System.Drawing.Size(174, 21);
            this.LongestWordLabel.TabIndex = 7;
            this.LongestWordLabel.Text = "Longest Word in File :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(82, 289);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(236, 21);
            this.label1.TabIndex = 8;
            this.label1.Text = "Most Vowelable Word in File :";
            // 
            // openFile
            // 
            this.openFile.FileName = "openFileDialog1";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.Font = new System.Drawing.Font("Segoe UI Black", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button1.ForeColor = System.Drawing.Color.Black;
            this.button1.Location = new System.Drawing.Point(412, 71);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(103, 43);
            this.button1.TabIndex = 9;
            this.button1.Text = "DESTROY!";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::ProgrammingProject3.Properties.Resources.background;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(745, 422);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.LongestWordLabel);
            this.Controls.Add(this.LastWordLabel);
            this.Controls.Add(this.FirstWordLabel);
            this.Controls.Add(this.FileFactsGroupBox);
            this.Controls.Add(this.ChooseFileButton);
            this.Controls.Add(this.ChooseFileLabel);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Text File Word Checker";
            this.FileFactsGroupBox.ResumeLayout(false);
            this.FileFactsGroupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label ChooseFileLabel;
        private System.Windows.Forms.Button ChooseFileButton;
        private System.Windows.Forms.Label FileFactsLabel;
        private System.Windows.Forms.TextBox FileFactsTextBox;
        private System.Windows.Forms.GroupBox FileFactsGroupBox;
        private System.Windows.Forms.Label FirstWordLabel;
        private System.Windows.Forms.Label LastWordLabel;
        private System.Windows.Forms.Label LongestWordLabel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.OpenFileDialog openFile;
        private System.Windows.Forms.SaveFileDialog saveFile;
        private System.Windows.Forms.Button button1;
    }
}

