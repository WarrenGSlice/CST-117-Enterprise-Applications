﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/* * * * * * * * * * * * *
 * * * Warren Peterson * *
 * This is my own Work * *
 * * * * CST-117 * * * * *
 * * * * 4/15/2021 * * * *
 *Programming Exercise 3 *
 * * * * * * * * * * * * */
namespace ProgrammingProject3
{
    public partial class Form1 : Form
    {
        // Variables
        string[] words; // Declares string array variable to hold words from file
        string first = null; // Declares Variable to contain the first word from file
        string last = null; // Declares Variable to contain the last word from file
        string longest = null; // Declares Variable to contain longest word from file
        string mostVowels = null; // Declares Variable to contain most vowelable word from file
        int mostVowelsCount = 0; // Variable that sets vowel count to type Integer
        StreamReader inputFile; //Variable that sets the opened file to the type StreamReader
        public Form1()
        {
            InitializeComponent();
        }

        // The Click Me Button
        private void ChooseFileButton_Click(object sender, EventArgs e)
        {
            // Loop that opens the text File
            if (openFile.ShowDialog() == DialogResult.OK)
            {
                List<string> completeWords = new List<string>(); // Variable that will be used to read whole words
                inputFile = File.OpenText(openFile.FileName); // Variable opens the text in the opened file

                // Loop that says if that files opened text is not at the end of the stream, Read the opened File
                // Line by line, convert the text to lower case and split the read lines into words and hold the
                // changed words in a string variable
                while (!inputFile.EndOfStream)
                {
                    foreach (string word in inputFile.ReadLine().ToLower().Split(' '))
                    {
                        completeWords.Add(word);
                    }
                }
                inputFile.Close(); // Close the File
                words = completeWords.ToArray(); // put the changed words in an array and hold them in this new variable

                // Loop that searches the changed words and iterates them through searching methods
                foreach (string word in words)
                {
                    findAlphabetical(word);
                    findLongestWord(word);
                    countVowels(word);
                }

                // String array that takes the results of the searching methods and holds them in a variable with display content
                string[] lines =
                {
                    first + "\n",
                    last + "\n",
                    longest + "\n",
                    mostVowels
                };
                FileFactsTextBox.Text = string.Join("\r\n", lines); // Displays selected results to the TextBox

                // Loop that allows user to Save results to a new file
                if (saveFile.ShowDialog() == DialogResult.OK)
                {
                    File.WriteAllLines(saveFile.FileName, lines);
                }
            }

            // Error Validation
            else
            {
                MessageBox.Show("You clicked the Cancel button.");
            }
        }

        //Method that finds the First Word and Last Word in the Specified File
        private void findAlphabetical(string word)
        {
            if (first == null)
            {
                last = word;
                first = word;
                return;
            }
            if (word.CompareTo(first) == 0)
            {
                first = word;
            }
            if (word.CompareTo(last) == -1)
            {
                inputFile = File.OpenText(openFile.FileName);
                last = Convert.ToString(inputFile.ReadToEnd().ToLower().Split(' ').Last());
                inputFile.Close();
            }
        }

        //Method that finds the Longest Word in the File
        private void findLongestWord(string word)
        {
            if (longest == null)
            {
                longest = word;
                return;
            }
            if (longest.Length < word.Length)
            {
                longest = word;
            }
        }

        //Method that finds the Most Vowelable Word in the File
        private void countVowels(string word)
        {
            int count = 0;
            for (int i = 0; i < word.Length; i++)
            {
                if (word[i] == 'a' || word[i] == 'e' || word[i] == 'i' || word[i] == 'o' || word[i] == 'u')
                {
                    count++;
                }
            }
            if (count > mostVowelsCount)
            {
                mostVowelsCount = count;
                mostVowels = word;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
