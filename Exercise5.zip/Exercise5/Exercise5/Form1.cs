﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/* * * * * * * * * * * * 
 * * Warren Peterson * *
 * This is my own work *
 * * *  4/14/2021  * * *
 * * * * CST-117 * * * *
 * * * * * * * * * * * */
namespace Exercise5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Calculate Button
        private void CalculateButton_Click(object sender, EventArgs e)
        {
            // Variables
            int terms; // Variable to take the number inputed into the Enter # of terms Text Box
            bool result = Int32.TryParse(InputTextBox.Text, out terms); // Variable that parses the input of the textBox and converts it to a 32 Integer

            // Loop that calculates the Result
            if (result)
            {
                // Variables
                decimal pi = 0; // Variable that declares the pi variable to type decimal
                decimal denominator = 1; // Variable that declares the denominator variable to type decimal
                int i; // variable that declares the i variable to type integer

                // Loop that calculates Pi
                for (i = 1; i <= terms; i++)
                {
                    if (i % 2 != 0)
                    {
                        pi = pi + (4 / denominator);
                    }
                    else
                    {
                        pi = pi - (4 / denominator);
                    }
                    denominator += 2;
                }
                // Sends results of calculations to correct Labels
                ReadInputLabel.Text = "Approximate value of Pi after " + terms + " terms : ";
                outputLabel.Text = "= " + pi;
            }
            else
            {
                // Error Message that pops up if anything other than a number is entered input the input Text box
                MessageBox.Show("Please enter a valid integer.", "Terms Error");
            }
        }

        // Exit button
        private void ExitButton_Click(object sender, EventArgs e)
        {
            // Closes Application
            this.Close();
        }

        // Reset Text Fields Button
        private void ResetButton_Click(object sender, EventArgs e)
        {
            // Resets to the beginning text field input messages
            InputLabel.Text = "";
            outputLabel.Text = "Waiting For Input...";
            ReadInputLabel.Text = "Waiting For Input...";
        }
    }
}
