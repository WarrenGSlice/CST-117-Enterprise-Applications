﻿
namespace Exercise5
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.InputLabel = new System.Windows.Forms.Label();
            this.InputTextBox = new System.Windows.Forms.TextBox();
            this.MathGroupBox = new System.Windows.Forms.GroupBox();
            this.outputLabel = new System.Windows.Forms.Label();
            this.ReadInputLabel = new System.Windows.Forms.Label();
            this.CalculateButton = new System.Windows.Forms.Button();
            this.ExitButton = new System.Windows.Forms.Button();
            this.ResetButton = new System.Windows.Forms.Button();
            this.MathGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // InputLabel
            // 
            this.InputLabel.AutoSize = true;
            this.InputLabel.BackColor = System.Drawing.Color.Black;
            this.InputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.InputLabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.InputLabel.ForeColor = System.Drawing.Color.White;
            this.InputLabel.Location = new System.Drawing.Point(70, 40);
            this.InputLabel.Name = "InputLabel";
            this.InputLabel.Size = new System.Drawing.Size(140, 23);
            this.InputLabel.TabIndex = 0;
            this.InputLabel.Text = "Enter # of terms :";
            // 
            // InputTextBox
            // 
            this.InputTextBox.Location = new System.Drawing.Point(243, 40);
            this.InputTextBox.Name = "InputTextBox";
            this.InputTextBox.Size = new System.Drawing.Size(100, 23);
            this.InputTextBox.TabIndex = 1;
            // 
            // MathGroupBox
            // 
            this.MathGroupBox.BackColor = System.Drawing.Color.SeaGreen;
            this.MathGroupBox.Controls.Add(this.ResetButton);
            this.MathGroupBox.Controls.Add(this.ExitButton);
            this.MathGroupBox.Controls.Add(this.outputLabel);
            this.MathGroupBox.Controls.Add(this.ReadInputLabel);
            this.MathGroupBox.Controls.Add(this.CalculateButton);
            this.MathGroupBox.Controls.Add(this.InputLabel);
            this.MathGroupBox.Controls.Add(this.InputTextBox);
            this.MathGroupBox.Location = new System.Drawing.Point(31, 34);
            this.MathGroupBox.Name = "MathGroupBox";
            this.MathGroupBox.Size = new System.Drawing.Size(420, 329);
            this.MathGroupBox.TabIndex = 2;
            this.MathGroupBox.TabStop = false;
            this.MathGroupBox.Text = "Approximate PI";
            // 
            // outputLabel
            // 
            this.outputLabel.AutoSize = true;
            this.outputLabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.outputLabel.Location = new System.Drawing.Point(22, 219);
            this.outputLabel.Name = "outputLabel";
            this.outputLabel.Size = new System.Drawing.Size(153, 21);
            this.outputLabel.TabIndex = 4;
            this.outputLabel.Text = "Waiting for input...";
            // 
            // ReadInputLabel
            // 
            this.ReadInputLabel.AutoSize = true;
            this.ReadInputLabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.ReadInputLabel.Location = new System.Drawing.Point(22, 166);
            this.ReadInputLabel.Name = "ReadInputLabel";
            this.ReadInputLabel.Size = new System.Drawing.Size(153, 21);
            this.ReadInputLabel.TabIndex = 3;
            this.ReadInputLabel.Text = "Waiting for input...";
            // 
            // CalculateButton
            // 
            this.CalculateButton.BackColor = System.Drawing.Color.Black;
            this.CalculateButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CalculateButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.CalculateButton.ForeColor = System.Drawing.Color.White;
            this.CalculateButton.Location = new System.Drawing.Point(243, 104);
            this.CalculateButton.Name = "CalculateButton";
            this.CalculateButton.Size = new System.Drawing.Size(100, 41);
            this.CalculateButton.TabIndex = 2;
            this.CalculateButton.Text = "Calculate";
            this.CalculateButton.UseVisualStyleBackColor = false;
            this.CalculateButton.Click += new System.EventHandler(this.CalculateButton_Click);
            // 
            // ExitButton
            // 
            this.ExitButton.BackColor = System.Drawing.Color.Black;
            this.ExitButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ExitButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.ExitButton.ForeColor = System.Drawing.Color.White;
            this.ExitButton.Location = new System.Drawing.Point(243, 266);
            this.ExitButton.Name = "ExitButton";
            this.ExitButton.Size = new System.Drawing.Size(100, 41);
            this.ExitButton.TabIndex = 5;
            this.ExitButton.Text = "Exit";
            this.ExitButton.UseVisualStyleBackColor = false;
            this.ExitButton.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // ResetButton
            // 
            this.ResetButton.BackColor = System.Drawing.Color.Black;
            this.ResetButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ResetButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.ResetButton.ForeColor = System.Drawing.Color.White;
            this.ResetButton.Location = new System.Drawing.Point(70, 266);
            this.ResetButton.Name = "ResetButton";
            this.ResetButton.Size = new System.Drawing.Size(100, 41);
            this.ResetButton.TabIndex = 6;
            this.ResetButton.Text = "Reset";
            this.ResetButton.UseVisualStyleBackColor = false;
            this.ResetButton.Click += new System.EventHandler(this.ResetButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Exercise5.Properties.Resources.math;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(479, 398);
            this.Controls.Add(this.MathGroupBox);
            this.Name = "Form1";
            this.Text = "Exercise 5";
            this.MathGroupBox.ResumeLayout(false);
            this.MathGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label InputLabel;
        private System.Windows.Forms.TextBox InputTextBox;
        private System.Windows.Forms.GroupBox MathGroupBox;
        private System.Windows.Forms.Label outputLabel;
        private System.Windows.Forms.Label ReadInputLabel;
        private System.Windows.Forms.Button CalculateButton;
        private System.Windows.Forms.Button ExitButton;
        private System.Windows.Forms.Button ResetButton;
    }
}

