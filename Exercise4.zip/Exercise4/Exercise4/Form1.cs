﻿using System;
using System.Windows.Forms;

namespace Exercise4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void CalculateButton_Click(object sender, EventArgs e)
        {
            double secondsPerMin = 60;
            double secondsPerHr = 3600;
            double secondsPerDay = 86400;

            // Try Parse Loop that validates data
            if (double.TryParse(enterSecondsTextBox.Text, out _))
            {
                // Variable that converts seconds entered to an integer with max 64 length
                Int64 totalSeconds = Convert.ToInt64(enterSecondsTextBox.Text);
                if (double.Parse(enterSecondsTextBox.Text) < secondsPerMin)
                {
                    secondsTextBox.Text = (totalSeconds % 60).ToString();
                    minutesTextBox.Text = "0";
                    hoursTextBox.Text = "0";
                    daysTextBox.Text = "0";
                }
                else if (double.Parse(enterSecondsTextBox.Text) >= secondsPerMin && (double.Parse(enterSecondsTextBox.Text)) < secondsPerHr)
                {
                    // Calculates the seconds entered and returns broken down values
                    secondsTextBox.Text = (totalSeconds % 60).ToString();
                    minutesTextBox.Text = ((totalSeconds % 3600) / 60).ToString();
                    hoursTextBox.Text = "0";
                    daysTextBox.Text = "0";
                }
                else if (double.Parse(enterSecondsTextBox.Text) >= secondsPerHr && (double.Parse(enterSecondsTextBox.Text)) < secondsPerDay)
                {
                    // Calculates the seconds entered and returns broken down values
                    secondsTextBox.Text = (totalSeconds % 60).ToString();
                    minutesTextBox.Text = ((totalSeconds % 3600) / 60).ToString();
                    hoursTextBox.Text = ((totalSeconds % 86400) / 3600).ToString();
                    daysTextBox.Text = "0";
                }
                else if (double.Parse(enterSecondsTextBox.Text) >= secondsPerDay)
                {
                    // Calculates the seconds entered and returns broken down values
                    secondsTextBox.Text = (totalSeconds % 60).ToString();
                    minutesTextBox.Text = ((totalSeconds % 3600) / 60).ToString();
                    hoursTextBox.Text = ((totalSeconds % 86400) / 3600).ToString();
                    daysTextBox.Text = ((totalSeconds % (86400 * 30)) / 86400).ToString();
                }
            }
            else
            {
                //Invalid Entry
                MessageBox.Show("Invalid Entry, Please enter a valid number");
            }
        }

        private void ClearButton_Click(object sender, EventArgs e)
        {
            daysTextBox.Text = "";
            hoursTextBox.Text = "";
            minutesTextBox.Text = "";
            secondsTextBox.Text = "";
            enterSecondsTextBox.Text = "";
        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
