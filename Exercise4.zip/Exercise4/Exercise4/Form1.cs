﻿using System;
using System.Windows.Forms;
/* Warren Peterson
 * 4/7/2021
 * CST 117
 * Exercise 4
 */

namespace Exercise4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void CalculateButton_Click(object sender, EventArgs e)
        {
            // Variables
            double secondsPerMin = 60; // variable that determines seconds in a minute
            double secondsPerHr = 3600; // variable that determines seconds in an hour
            double secondsPerDay = 86400; // variable that determines seconds in a day

            // Try Parse Loop that validates data
            if (double.TryParse(enterSecondsTextBox.Text, out _))
            {
                // Variable that converts seconds entered and returns a whole number
                Int64 totalSeconds = Convert.ToInt64(enterSecondsTextBox.Text);

                // Parses the seconds entered and returns true if less than 60 is entered
                if (double.Parse(enterSecondsTextBox.Text) < secondsPerMin)
                {
                    // Calculates the seconds entered and returns broken down values
                    secondsTextBox.Text = (totalSeconds % 60).ToString();
                    minutesTextBox.Text = "0";
                    hoursTextBox.Text = "0";
                    daysTextBox.Text = "0";
                }

                // Parses the seconds entered and returns true if less than 3600 is entered
                else if (double.Parse(enterSecondsTextBox.Text) >= secondsPerMin && (double.Parse(enterSecondsTextBox.Text)) < secondsPerHr)
                {
                    // Calculates the seconds entered and returns broken down values
                    secondsTextBox.Text = (totalSeconds % 60).ToString();
                    minutesTextBox.Text = ((totalSeconds % 3600) / 60).ToString();
                    hoursTextBox.Text = "0";
                    daysTextBox.Text = "0";
                }

                // Parses the seconds entered and returns true if less than 86400 is entered
                else if (double.Parse(enterSecondsTextBox.Text) >= secondsPerHr && (double.Parse(enterSecondsTextBox.Text)) < secondsPerDay)
                {
                    // Calculates the seconds entered and returns broken down values
                    secondsTextBox.Text = (totalSeconds % 60).ToString();
                    minutesTextBox.Text = ((totalSeconds % 3600) / 60).ToString();
                    hoursTextBox.Text = ((totalSeconds % 86400) / 3600).ToString();
                    daysTextBox.Text = "0";
                }

                // Parses the seconds entered and returns true if more than 86400 is entered
                else if (double.Parse(enterSecondsTextBox.Text) >= secondsPerDay)
                {
                    // Calculates the seconds entered and returns broken down values
                    secondsTextBox.Text = (totalSeconds % 60).ToString();
                    minutesTextBox.Text = ((totalSeconds % 3600) / 60).ToString();
                    hoursTextBox.Text = ((totalSeconds % 86400) / 3600).ToString();
                    daysTextBox.Text = ((totalSeconds % (86400 * 30)) / 86400).ToString();
                }
            }
            // Error Validation else statement
            else
            {
                //Invalid Entry opens a pop up window
                MessageBox.Show("Invalid Entry, Please enter a valid number");
            }
        }

        // Clear button clears all fields
        private void ClearButton_Click(object sender, EventArgs e)
        {
            daysTextBox.Text = "";
            hoursTextBox.Text = "";
            minutesTextBox.Text = "";
            secondsTextBox.Text = "";
            enterSecondsTextBox.Text = "";
        }

        // Exit Button closes program window
        private void ExitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
